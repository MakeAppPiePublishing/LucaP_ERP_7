//
//  File.swift
//  LucaP - An ERP to learn from
//
//  Created by Steven Lipton on 5/15/25.
//

import SwiftUI

struct ContentHeaderView:View{
    @Binding  var path:String
    var body:some View{
        HStack{
            Image("LucaP_75px")
                .resizable()
                .frame(width:40,height:40)
            Text("LucaP ERP System: " + path)
                .font(.headline).bold()
            Spacer()
            Text(Date(),style:.date)
            Text(Date(),style:.time)
                .padding(.trailing)
        }
    }
}
