import SwiftUI

struct MenuView:View{
    var menu:LucaMenuModel
    let columns = Array(repeating: GridItem(.fixed(125), spacing: 5, alignment: .top), count: 6)
    @State var selected:LucaMenuItem = LucaMenuItem(id: -1, title: "NULL")
    @State var presentMenuItem:Bool = false
    var body: some View {
        
            LazyVGrid(columns: columns){
                ForEach(menu.menuItems){item in 
                     
                        Text(item.title)
                            .font(.caption)
                            .padding(3)
                            .frame(width:100,height: 100)
                            .background(.regularMaterial)
                            .onTapGesture{
                                selected = item
                                presentMenuItem = true
                            }
                    
                }
            }
            
        
    }
    
}


#Preview{
    MenuView(menu: LucaMenuModel(titles: ["Finance","Banking","Accounts Recievable","Accounts Payable","Inventory","Production","Sales","Logistics"]))
}
