import SwiftUI

struct LPCheckBox:View{
    var label:String
    @Binding var value:Bool
    var isActive:Bool
    
    var backgroundStyle:any ShapeStyle{
        isActive ? .white : .secondary
    }
    var body: some View{
        HStack{
            HStack{
                Spacer()
                Text(label).font(.caption).bold()
                    .padding(.trailing)
            }
            .frame(width:totalFieldWidth * 0.25)
                
                Image(systemName: value ? "x.square.fill": "square")
                    .imageScale(.large)
                    .padding(8)
                    .background(isActive ? .clear : .inactiveBackground)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .onTapGesture{
                        if isActive{
                            value.toggle()
                        }
                    }
                  Spacer()
                
            }
            .frame(width:totalFieldWidth)
        
    }
}

#Preview{
    LPCheckBox(label: "Check On", value: .constant(false), isActive: true)
}
