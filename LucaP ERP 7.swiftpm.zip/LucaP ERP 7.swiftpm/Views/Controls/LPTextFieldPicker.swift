import SwiftUI

/// A text field with an button to lauch a view's presentation 
/// - parameter label: the name of the field
/// - parameter contents: the value of the field
/// - parameter present: tell the superview to present a view
struct LPTextFieldPicker:View{
    var label:String
    @Binding var contents:String
    @Binding var present:Bool
    var isActive:Bool = true
    
    var body: some View{
        HStack{
            TextField(label, text: $contents)
                .lpFieldModifier(label: label, value: contents, isActive: isActive)
            Button{
                present = true
            } label:{
                Image(systemName: "magnifyingglass.circle")
                    .imageScale(.large)
            }
        }
    }
    
}

#Preview{
    LPTextField(label:"Name",contents:.constant("Nova"),isActive:true)
}
