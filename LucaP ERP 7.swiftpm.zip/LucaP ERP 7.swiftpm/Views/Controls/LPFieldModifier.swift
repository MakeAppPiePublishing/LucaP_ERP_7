import SwiftUI
// LPFieldModifier 
// Steven Lipton 2/22/25
// 
//


let totalFieldWidth = 500.00
/// The formatting modifer to add a leading label to any view
/// 
struct LPFieldModifier:ViewModifier{
    var label:String
    var value:String
    var isActive:Bool = true
    
    func body(content:Content)-> some View{
        HStack{
            HStack{
                Spacer()
                Text(label)
                    .font(.caption).bold()
                    
            }
            if isActive{
                content
                    .textFieldStyle(.roundedBorder)
                    .frame(width:totalFieldWidth * 0.75,height:40)
            } else {
                ZStack(alignment:.center){
                    RoundedRectangle(cornerRadius:8)
                        .foregroundStyle(.regularMaterial)
                        .frame(width:totalFieldWidth * 0.75,height:40)
                    HStack{
                        Text(value)
                            .padding(5)
                        Spacer()
                    }
                    
                }
            }
            
            Spacer()
        }
        .frame(width:totalFieldWidth)
        
    }
}

extension View{
    func lpFieldModifier(label:String,value:String,isActive:Bool = true) -> some View{
        self.modifier(LPFieldModifier(label: label, value: value, isActive: isActive))
    }
    
    static  var inactiveBackground:Color{Color(white: 0, opacity: 0.10)}
    
}
