import SwiftUI

struct LPTextField:View{
    var label:String
    @Binding var contents:String
    var isActive:Bool = true
    
    var body: some View{
        HStack{
            TextField(label, text: $contents)
                .lpFieldModifier(label: label, value: contents, isActive: isActive)
            }
        }
        
    }

#Preview{
    LPTextField(label:"Name",contents:.constant("Keiko Lopez"),isActive:false)
}
