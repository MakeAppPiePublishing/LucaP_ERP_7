import SwiftUI

// --- LPChartOfAccountsFormView
// --- Complete revision 5/8/2025
// (c) 2025 Steven Lipton
// A form-based view for adding and editing a chart of account entry



/// A form-based view for adding and editing a chart of account entry
/// - parameter chartOfAccounts: The model passed with a @Bindable 
struct LPChartOfAccountsFormView:View{
    
// ----- Parameters    
    ///The model 
    /// - TODO: once set up in menu form, pass this as Binding
    @State var chartOfAccounts: ChartOfAccounts = ChartOfAccounts()
    
    
    /// For use in View navigation, present or dismiss the view. 
    /// - TODO: for noe set to @State. chang to @Binding in final version
    @State var isPresented:Bool = true
    
// ---- Private variables
    
    //The selected account to display
    @State private var selectedAccount:Account = ChartOfAccounts().nullAccount
    
    
    //State variables for the UI
    @State private var accountNumber:String = ""
    @State private var accountName:String = ""
    @State private var accountCategory: Int = 0
    @State private var accountIsActive:Bool = true
    @State private var creditTotal:Float = 0.0
    @State private var debitTotal:Float = 0.0
    
    //--- flags 
    /// read only form
    /// - used by fields to determine if read-only
    /// - `false` is read-only
    @State private var formActive:Bool = true
    
    /// keys read only
    /// - used by keys to determine read write independent of `formActive`
    /// - `false` is read-only
    @State private var keyActive:Bool = true
    
    ///A flag to present the selection sheet for the key
    @State private var presentKeyList:Bool = false
    
    /// Status for the form 
    // TODO: Should this just be displayMode? 
   // @State private var formStatus:CRUDAction = .search
    
    /// The display mode status 
    @State private var displayMode:CRUDAction = .search
    
    /// Indicates the navigation action required
    @State private var navigationAction:NavigationAction = .noAction
    
    
    
    /// flag to perform action
    @State private var doAction:Bool = false
    
    //TODO remove this once complete 
    //@State var index:Int! = nil 
    
    ///Error handling - error message 
    @State private var errorType:ErrorType = .noError
    
    ///Error handling and messaging in error bar. 
    @State private var message:String = "LucaP ERP ready"
    @State private var topMessage1 = ""
    @State private var topMessage2 = ""
    
    //refreshes the Value in the UI's views 
    func refreshUI(with account:Account){
        accountNumber = account.accountNumber
        accountName = account.accountName
        accountCategory = account.accountCategory
        accountIsActive = account.isActive
        creditTotal = account.creditTotal
        debitTotal =  account.debitTotal
    }
    
    func updateModel(account:Account) -> ErrorType {
        chartOfAccounts.update(account: account, with: account)
    }
    
    func addModel(account:Account)-> ErrorType{
        chartOfAccounts.add(account: account)
    }
    
/// Removed and replaced with model's version 5/3/25
    //    var sortedAccounts:[Account]{
    //        return chartOfAccounts.accounts.sortedAccounts()
    //    }
/// Removed and replaced with model's version 5/3/25    
    /// identifiy the current id
//    var idValue:String{
//        if let index = self.index{
//            return chartOfAccounts.sortedAccounts()[index].id
//        } 
//        return ""
//    }
    
    
    var body: some View{
        VStack{
            //navigation bar
            LPNavigationBar(navAction: $navigationAction, displayMode: $displayMode,message1: topMessage1,message2: topMessage2)
            // two columns for a form
            HStack(alignment:.top){
                // first column
                VStack(alignment:.leading){
                    LPTextFieldPicker(label: "Account#", contents:$accountNumber ,present:$presentKeyList, isActive: keyActive)
                    LPTextField(label: "Account Name", contents: $accountName, isActive: formActive)
                    LPIntPicker(label: "Category", value: $accountCategory, choices: AccountCategories().accountCategories.map{($0.id,$0.name)}, isActive: formActive)
                    LPCheckBox(label: "Active", value: $accountIsActive, isActive: formActive)
                    Spacer()
                    
                }
                //second column
                VStack(alignment:.leading){
                    LPCurrencyField(label: "Total Debits", value: $debitTotal, isActive: false)
                    LPCurrencyField(label: "Total Credits", value: $creditTotal, isActive: false)
                    Spacer()
                }
                // add list here if using one
                
                //debugging code -- delete after diagnostics
                Text(navigationAction.rawValue)
                Text(displayMode.rawValue)
            }
            .sheet(isPresented: $presentKeyList) { 
                refreshUI(with: selectedAccount)
            } content:{
                LPChartOfAccountsListView(selected: $selectedAccount, isPresented: $presentKeyList)
            }
            Spacer()
            // Footer -- info bar. 
            LPBottomToolbar(error:$errorType,message:$message,action:$displayMode,isPresented: $isPresented,doAction: $doAction)
        }
        .onChange(of: selectedAccount) { 
            refreshUI(with: selectedAccount)
        }
        .onChange(of:doAction){
            if doAction{
                performAction()
            }
        }
        .onChange(of:displayMode){
            changeDisplayMode()
        }
        .onChange(of:navigationAction){
            if navigationAction != .noAction{
                rowNavigation()
            }
        }
    }
    
    func changeDisplayMode(){
        switch displayMode{
        case .add:
            selectedAccount = .blank
            formActive = true
            keyActive = true
            message = "Add new"
        case .update:
            // if the accountNumber is not a valid entry, go into search mode if valid edit everything but the key
            if chartOfAccounts.account(at: accountNumber).accountNumber.isEmpty{
                displayMode = .search
                message = "Search for account number"
            } else {
                formActive = true
                keyActive = false
                
            }
        case .search:
            selectedAccount = .blank
            formActive = false
            keyActive = true
            displayMode = .view
            message = "Search for account number"
        case .view:
            // if the accountNumber is not a valid entry, go into search mode if valid view everything
            if chartOfAccounts.account(at: accountNumber).accountNumber.isEmpty{
                displayMode = .search
                message = "Search for account number"
            } else {
                formActive = false
                keyActive = false
                message = "View: Account number " + accountNumber
                
            }
        default:
            //do nothing
            formActive = formActive
        }
    }
    
    func rowNavigation(){
        displayMode = .view
        switch navigationAction {
        case .first:
            selectedAccount = chartOfAccounts.firstAccount()
            message = "First Account"
        case .previous:
                selectedAccount = chartOfAccounts.previousAccount(before: accountNumber)
            // when blank, go to first account
            if selectedAccount.accountNumber == ""{
                selectedAccount = chartOfAccounts.firstAccount()
                message = "First Account"
            }
        case .next:
            selectedAccount = chartOfAccounts.nextAccount(after: accountNumber)
            //when blank go to last account
            if selectedAccount.accountNumber == ""{
                selectedAccount = chartOfAccounts.lastAccount()
                message = "Last Account"
            }
        case .last:
            selectedAccount = chartOfAccounts.lastAccount()
            message = "Last Account"
        default: 
            //do nothing 
            navigationAction = .noAction
        }
        //reset the action
        topMessage2 = navigationAction.rawValue + ":" + selectedAccount.accountNumber
        navigationAction = .noAction
    }
    
    func performAction(){
        let newAccount = Account(accountNumber: accountNumber, accountName: accountName, accountCategory: accountCategory)
        switch displayMode{
        case .add:
            errorType = chartOfAccounts.add(account:newAccount)
            if errorType == .noError{
                message = "\(accountNumber) added sucessfully"
                displayMode = .update
            } else {
                message = "\(accountNumber) not added"
            }
        case .update:
            errorType = updateModel(account: newAccount)
            if errorType == .noError{
                message = "\(accountNumber) updated sucessfully"
            } else {
                message = "\(accountNumber) not updated"
            }
            
        case .search:
            let result = chartOfAccounts.find(accountNumber:accountNumber)
            errorType = result.errorType
            if errorType == .noError{
                selectedAccount = result.account
                message = "\(accountNumber) found"
            } else {
                message = "\(accountNumber) not found"   
            }
        case .delete:
            errorType = chartOfAccounts.remove(account: selectedAccount)
            if errorType == .noError{
                message = "Sucessfully deleted"
            } else {
                message = "No action taken"
            }
        default:
            // do nothing
            break
        }
        doAction = false
    }
}

#Preview{
    LPChartOfAccountsFormView()
}
