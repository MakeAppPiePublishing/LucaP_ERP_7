import SwiftUI

struct LPChartOfAccountsFormView_OLD:View{
    @State private var chartOfAccounts: ChartOfAccounts = ChartOfAccounts()
    @State private var accountNumber:String = ""
    @State private var accountName:String = ""
    @State private var accountCategory: Int = 0
    @State private var accountIsActive:Bool = true
    @State private var creditTotal:Float = 0.0
    @State private var debitTotal:Float = 0.0
    @State private var readWriteForm:Bool = true
    @State private var showAccountSheet:Bool = false
    @State private var selectedAccount:Account =  Account(accountNumber: "", accountName: "", accountCategory: 0)
    @State private var index:Int! = nil
    @State private var newEntry = true
    
    //added 5/3/25 - error handling
    @State private var errorType:ErrorType = .noError
    
    //changes label on button for states of okay,Add,and, change
    var okayButtonLabel:String{
        if readWriteForm{
            if index == nil {
                return "Add"
            } else {
                return "Change"
            }
        } else {
            return "Okay"
        }
    }
    
    //refreshes the Value in the UI's views wiht an account number
    func refreshUI(with account:Account){
        accountNumber = account.accountNumber
        accountName = account.accountName
        accountCategory = account.accountCategory
        accountIsActive = account.isActive
        creditTotal = account.creditTotal
        debitTotal =  account.debitTotal
        newEntry = accountNumber == ""
    }
    
    func refreshUI(index:Int!){
        if let index = index{
            selectedAccount = chartOfAccounts.sortedAccounts()[index]
            refreshUI(with: selectedAccount)
        } else{
            accountNumber = ""
            accountName = ""
            accountCategory = 0
            accountIsActive = true
            creditTotal = 0
            debitTotal =  0
        }
    }
    
    func updateModel(account:Account){
        errorType = chartOfAccounts.update(account: account, with: account)
    }
    
    func addModel(account:Account){
        errorType = chartOfAccounts.add(account: account)
    }
    /// Removed and replaced with model's version 5/3/25
//    var sortedAccounts:[Account]{
//        return chartOfAccounts.accounts.sortedAccounts()
//    }
    
    /// identifiy the current id
    var idValue:String{
        if let index = self.index{
            return chartOfAccounts.sortedAccounts()[index].id
        } 
        return ""
    }
    
    
    var body: some View{
        VStack(alignment:.leading){
//            LPFileNavigationBar(
//                index: $index,
//                maxIndex: chartOfAccounts.accounts.count,
//                readWrite: $readWriteForm
//            )
            HStack(alignment:.top){
                VStack(alignment:.leading){
                    if index == nil{
                        LPTextFieldPicker(label: "Account#", contents:.constant(idValue) ,present:$showAccountSheet, isActive: readWriteForm)
                    } else {
                        LPTextFieldPicker(label: "Account#", contents: .constant(idValue),present:$showAccountSheet, isActive: false)
                    }
                    LPTextField(label: "Account Name", contents: $accountName, isActive: readWriteForm)
                    LPIntPicker(label: "Category", value: $accountCategory, choices: AccountCategories().accountCategories.map{($0.id,$0.name)}, isActive: readWriteForm)
                    LPCheckBox(label: "Active", value: $accountIsActive, isActive: readWriteForm)
                    Spacer()
                    
                }
                VStack(alignment:.leading){
                    LPCurrencyField(label: "Total Debits", value: $debitTotal, isActive: false)
                    LPCurrencyField(label: "Total Credits", value: $creditTotal, isActive: false)
                    Spacer()
                }
            }
            .sheet(isPresented: $showAccountSheet) { 
                refreshUI(with: selectedAccount)
            } content:{
                LPChartOfAccountsListView(selected: $selectedAccount, isPresented: $showAccountSheet)
            }
            Spacer()
            // Footer -- info bar. 
            HStack{
              if index == nil{
                  Text("Add Mode")
              } else {
                  if index == chartOfAccounts.sortedAccounts().count - 1{
                      Text("Last Record")
                  }
                  if index == 0 {
                      Text("First Record")
                  }
              }
              Spacer()
                Button(okayButtonLabel){
                    //consolidate the UI information into an account
                    let account = Account(accountNumber: accountNumber, accountName: accountName, accountCategory: accountCategory)
                    if readWriteForm{
                        if index == nil{
                            addModel(account: account)
                        } else {
                            updateModel(account:account)
                        }
                    } else {
                        //dismissal code here
                    }
                }
                .frame(minWidth:125)
                .buttonModifier
                
                Button("Cancel"){
                    //dismissal code here
                }
                .frame(minWidth:125)
                .buttonModifier
                
            }
            .padding()
            .background(.thinMaterial)

        }
        .onChange(of: index) { oldValue, newValue in
            refreshUI(index: newValue)
        }
    }
}

#Preview{
    LPChartOfAccountsFormView()
}
