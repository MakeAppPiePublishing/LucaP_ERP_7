import SwiftUI

//moved from `JournalTransaction`
var globalJournalEntryID = 100

//Journal Entry - a entry in the general journal containng transactions and other information

class JournalEntry:Identifiable{
    // The external Idetifier of the entry
    var docId:Int
    var date:Date
    var description:String
    //var journalTransactions:[JournalTransaction] = []
    var remarks:String = ""
    
    //Computed properties
    //The internal Identifier
    var id:Int{docId}
    
    var totalDebits:Double{totalAmount(creditDebit: .debit)}
    var totalCredits:Double{totalAmount(creditDebit: .credit)}
    
    var balancedEntry:Bool{
        totalDebits == totalCredits
    }
    
    /// Initialize a new instance of `JournalEntry`
    /// - Most of the properties are automaitcally initialized, except description. 
    init(description:String){
        self.docId = globalJournalEntryID
        globalJournalEntryID += 1
        self.date = Date()
        self.description = description
    }
    
    /// Import all data into `JournalEntry`
    /// - mostly for testing purposes now
    init(docId:Int,description:String, date:Date = Date()){
        self.docId = docId
        // TODO: This needs revision if used for import. Set to error on a conflict. Okay now for testing the model. 
         if globalJournalEntryID < docId{
             globalJournalEntryID = docId
         }
        self.date = Date()
        self.description = description
        //fetchJournalTransactions()
    }
    
    /// Filter to only transactions with this `docId`
    /// - In pseudo SQL `SELECT t1.* FROM t0 INNER JOIN t1 ON t1.docId = t0.docId`
    func fetchJournalTransactions()->[JournalTransaction]{
        let transactionTable = JournalTransactions().transactions
        return transactionTable.filter({$0.docId == docId})
    }
    
    /// Compute the total credits or debits in the transactions
    func totalAmount(creditDebit:CreditDebit)->Double{
        var total:Double = 0
        for row in fetchJournalTransactions(){
            if row.creditDebit == creditDebit{
                total += row.amount
            }
        }
        return total
    }
}

class JournalEntries{
    var journalEntries:[JournalEntry]
    
    init(){
        self.journalEntries = testEntries
    }
    
    var testEntries = [
        JournalEntry(docId: 100, description: "Initial investment"),
        JournalEntry(docId:101, description: "Purchase Ingredients - CostCo"),
        JournalEntry(docId: 102, description: "Purchase Ingredients - Mike's Chicken"),
        JournalEntry(docId: 103, description: "Rent Pizza Oven"),
        JournalEntry(docId: 104, description: "Rent Sales Space"),
        JournalEntry(docId: 105, description: "Sales at Swap Meet")
    ]
}
