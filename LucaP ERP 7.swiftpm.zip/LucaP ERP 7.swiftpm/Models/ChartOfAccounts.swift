import SwiftUI

@Observable
class ChartOfAccounts{
    var accounts:[Account]
    let nullAccount = Account(accountNumber: "", accountName: "", accountCategory: 0)
    init(){
        self.accounts = []
        basicAccounts() 
    }
    
    // add account - 5/2/25
    func add(account:Account)-> ErrorType{
        if exists(account: account){
            return .recordExists
        } else {
            accounts.append(account)
        }
        return .noError
    }
    
    // find / read account
    func account(at accountNumber:String) -> Account{
        accounts.first{$0.accountNumber == accountNumber} ?? nullAccount
    }
    
    func find(accountNumber:String) -> (account:Account,errorType:ErrorType){
        if let account = accounts.first(where:{row in row.accountNumber == accountNumber }){
            return (account,.noError)
        } else {
            return (nullAccount,.recordNotFound)
        }
    }
    
    // list all active accounts, unless specified otherwise
    func activeAccounts(includeInactive:Bool = false) -> [Account]{
        if includeInactive{
            return accounts
        }
        
        return accounts.filter{ row in 
            row.isActive == true     
        }
    }
    
    func exists(account:Account)-> Bool{
        accounts.contains(where:{row in row.id == account.id})
    }
    
    func lastAccount()->Account{
        return sortedAccounts().last ?? nullAccount   //updated 5/2/25
    }
    
    func firstAccount()->Account{
        return sortedAccounts().first ?? nullAccount //updated 5/2/25
    }
    
    func previousAccount(before id:String)->Account{
        let sortedAccounts = sortedAccounts() //added 5/2/25
        if let index = sortedAccounts.firstIndex(where: {$0.accountNumber == id }){
            let newIndex = index - 1
            if newIndex >= 0{
                return sortedAccounts[newIndex]
            } else {
                return sortedAccounts.last ?? nullAccount
            }
        }
        return nullAccount
    }
    
    func nextAccount(after id:String)->Account{
        let sortedAccounts = sortedAccounts() //added 5/2/25
        if let index = sortedAccounts.firstIndex(where: {$0.accountNumber == id}){
            let newIndex = index + 1
            if newIndex != sortedAccounts.count{
                return sortedAccounts[newIndex]
            } else {
                return sortedAccounts.first ?? nullAccount
            }
        }
        return nullAccount
    }
    
    // updating
    func update(account:Account, with newAccount:Account)-> ErrorType{
        if let index = accounts.firstIndex(where: {
            row in row.id == account.id}){
            if account.isActive{
                accounts[index] = newAccount
                return .noError
            } else { // inactive account can only toggle activity
                if newAccount.isActive{
                    accounts[index].isActive = true
                    return .noError
                } else {
                    return .readOnly
                }
            }
        }
        return .recordNotFound
    }
    
    func update(accountID:String, with newAccount:Account, isActive:Bool)-> ErrorType{
        if let index = accounts.firstIndex(where: {
            row in row.id == accountID}){
            if isActive{
                accounts[index] = newAccount
                return .noError
            } else { // inactive account can only toggle activity
                if newAccount.isActive{
                    accounts[index].isActive = true
                    return .noError
                } else {
                    return .readOnly
                }
            }
        }
        return .recordNotFound
    }
    
    // deleting accounts
    // deletion of CoA entries not allowed.
    func remove(account:Account)->ErrorType{
        return .noDelete
    }
    
    // sorting accounts
    
    /// basic sorted accounts computerd property replaced with func  below
//    var sortedAccounts:[Account]{
//        accounts.sorted(by: {$0.accountNumber < $1.accountNumber })
//    }
    
    
/// Sort by account number. If necessary, exclude inactive accounts
/// - Parameter includeInactive: if true, removes inactive accounts in sort.
    func sortedAccounts(includeInactive:Bool = false) -> [Account]{
        if includeInactive{
            return accounts.sorted(by: {$0.accountNumber < $1.accountNumber })
        } else {
            return activeAccounts().sorted{ row1,row2 in
                row1.accountNumber < row2.accountNumber    
            }
        }
    }
    
    func sortedAccountCategory(_ categoryID:Int,includeInactive:Bool = false) -> [Account]{
        
        let categoryAccounts = activeAccounts().filter{ row in 
            row.accountCategory == categoryID    
        }
        
        if includeInactive{
            return categoryAccounts.sorted { row1, row2 in
                row1.accountNumber < row2.accountNumber
            }
        } 
        
        let active = categoryAccounts.filter{ row in
            row.isActive == true
        }
        
        return active.sorted{ row1,row2 in
            row1.accountNumber < row2.accountNumber    
        }

    }



// preloading data
func basicAccounts(){
    //Start with common accounts
    self.accounts = [
        Account(accountNumber: "111000", accountName: "Cash on Hand", accountCategory: 1),
        Account(accountNumber: "112000", accountName: "Cash in Bank", accountCategory: 1),
        Account(accountNumber: "121000", accountName: "Accounts Recievable", accountCategory: 1),
        Account(accountNumber: "131000", accountName: "Inventory - Raw Material", accountCategory: 1),
        Account(accountNumber: "131100", accountName: "Inventory - Ingredients", accountCategory: 1),
        Account(accountNumber: "131200", accountName: "Inventory - Single Use Utensils/Packaging", accountCategory: 1),
        Account(accountNumber: "132000", accountName: "Inventory - Work in Progress", accountCategory: 1),
        Account(accountNumber: "133000", accountName: "Inventory - Assembled Parts", accountCategory: 1),
        Account(accountNumber: "134000", accountName: "Inventory - Finshed Goods", accountCategory: 1),
        Account(accountNumber: "135000", accountName: "Inventory - Purchased Finshed Goods", accountCategory: 1),
        Account(accountNumber: "161000", accountName: "Production Equipment", accountCategory: 1),
        Account(accountNumber: "162000", accountName: "Office Equipment", accountCategory: 1),
        Account(accountNumber: "163000", accountName: "Motor Vehicles", accountCategory: 1),
        Account(accountNumber: "171000", accountName: "Production Equipment", accountCategory: 1),
        Account(accountNumber: "172000", accountName: "Office Equipment", accountCategory: 1),
        Account(accountNumber: "173000", accountName: "Motor Vehicles", accountCategory: 1),
        Account(accountNumber: "173100", accountName: "Motor Vehicles - Food Trucks ", accountCategory: 1),
        Account(accountNumber: "211000", accountName: "Accounts Payable", accountCategory: 2),
        Account(accountNumber: "311000", accountName: "Common Stock", accountCategory: 3),
        Account(accountNumber: "321000", accountName: "Paid in Capital", accountCategory: 3),
        Account(accountNumber: "331000", accountName: "Retained Earnings", accountCategory: 3),
        Account(accountNumber: "411000", accountName: "Sales Revenues ", accountCategory: 4),
        Account(accountNumber: "511000", accountName: "COGS", accountCategory: 5),
        Account(accountNumber: "611000", accountName: "Payroll", accountCategory: 6),
        Account(accountNumber: "621000", accountName: "Equipment Rental",
                accountCategory: 6),
        Account(accountNumber: "652100", accountName: "Space Rental",accountCategory: 6),
        Account(accountNumber: "631000", accountName: "Administrative Expense", accountCategory: 6),
        Account(accountNumber: "651000", accountName: "Office Supplies", accountCategory: 6),
        Account(accountNumber: "652000", accountName: "Sales and Marketing", accountCategory: 6)
        
    ]
}
}
